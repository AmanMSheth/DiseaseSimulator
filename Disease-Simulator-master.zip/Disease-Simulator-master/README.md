# Disease-Simulator
Disease Simulator code and assets for Unity 2018.2.15f1
Move the file inside the zip into your Documents folder by default, or your default Unity projects file.
